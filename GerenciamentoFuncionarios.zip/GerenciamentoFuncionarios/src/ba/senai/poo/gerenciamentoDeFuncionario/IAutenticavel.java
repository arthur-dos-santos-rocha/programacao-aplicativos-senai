package ba.senai.poo.gerenciamentoDeFuncionario;

public interface IAutenticavel {
	
	public static final String senha = "";

	
}
