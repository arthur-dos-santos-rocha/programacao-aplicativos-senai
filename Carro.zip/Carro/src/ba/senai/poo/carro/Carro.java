package ba.senai.poo.carro;

public class Carro {
	String cor;
	String modelo;
	double velocidadeAtual;
	double velocidadeMaxima;
	boolean ligado = false;
	Integer marcha;

	public void ligarCarro() {
		this.ligado = true;
		System.out.println("Carro ligado");
	}

	public void desligarCarro() {
		this.ligado = false;
		System.out.println("Carro desligado");
	}

	public void acelerar(Integer acelerando) {
		if (ligado && acelerando > 0) {
			velocidadeAtual += acelerando;

			if (velocidadeAtual > velocidadeMaxima) {
				velocidadeAtual = velocidadeMaxima;
			}
		}
	}

	public void freiar(Integer freio) {
		this.velocidadeAtual -= freio;
	}

	public Integer passarMarcha() {
		if (velocidadeAtual > 0 && velocidadeAtual <= 20) {
			this.marcha = 1;
		} else if (velocidadeAtual > 21 && velocidadeAtual <= 40) {
			this.marcha = 2;
		} else if (velocidadeAtual > 41 && velocidadeAtual <= 60) {
			this.marcha = 3;
		}
		if (velocidadeAtual > 61 && velocidadeAtual <= 100) {
			this.marcha = 4;
		}
		if (velocidadeAtual > 100) {
			this.marcha = 5;
		}
		return this.marcha;
		}

	public void consultar() {
		System.out.println("Carro ligado: " + ligado);
		System.out.println("Cor: " + cor);
		System.out.println("Modelo: " + modelo);
		System.out.println("Velocidade atual: " + velocidadeAtual + " km/h");
		System.out.println("Velocidade máxima: " + velocidadeMaxima + " km/h");
		System.out.println("Marcha atual: " + passarMarcha());
	}

}
