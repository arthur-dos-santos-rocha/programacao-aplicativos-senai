package ba.senai.poo.computadores;

public class Principal {

	public static void main(String[] args) {
		
		Monitor monitor = new Monitor(22,"Led",820.0);
		Computador computador = new Computador("Lenovo", "Preto", "Notebook", 2485.0, monitor);
		
		
		System.out.println(
				"O valor total do computador "+ computador.marca + 
				" Com a cor "+computador.cor+ " com o tamanho de "
						+monitor.tamanho+ " polegadas "+monitor.tipoMonitor
								+ " Ficou de: R$ "+computador.valorTotal());
	}

}
