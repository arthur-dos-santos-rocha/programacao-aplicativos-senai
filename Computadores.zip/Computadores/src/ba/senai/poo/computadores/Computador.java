
package ba.senai.poo.computadores;

public class Computador {

    String marca;
    String cor;
    String modelo;
    double valorComputador;
    Monitor monitor;

    public Computador(String marca, String cor, String modelo,
                      double valorComputador, Monitor monitor) {

        this.marca = marca;
        this.cor = cor;
        this.modelo = modelo;
        this.valorComputador = valorComputador;
        this.monitor = monitor;
    }

    public double valorTotal() {
        return valorComputador + monitor.preco;
    }
}
