package ba.senai.poo.contaBancaria;

public class ContaBancaria {
	
	private String titular;
	private double saldo;
	private double saldoInicial;
	
	
	
	public ContaBancaria(String titular, double saldo, double saldoInicial) {
		super();
		this.titular = titular;
		this.saldo = saldo;
		this.saldoInicial = saldoInicial;
	}



	public double getSaldo() {
		return saldo;
	}



	public void setSaldo(double saldo) {
		if(saldo <0) {
			System.out.println("O valor do saldo esta negativo, vai dar erro!");
			throw new IllegalArgumentException("Valor inválido!");
		}else {
			this.saldo = saldo;
		}
	}


	public String getTitular() {
		return titular;
	}



	public void setTitular(String titular) {
		this.titular = titular;
	}
	
	public void exibirDados() {
		System.out.println("Nome: "+ titular +
				"\n Saldo da conta: "+saldo+"\n O saldo inicial foi de "+saldoInicial);
	}
	

}
