package ba.senai.poo.gerenciamentoDeFuncionario;

public class Gerente extends Funcionario implements IAutenticavel{

	public Gerente(String nome, double salarioBase) {
		super(nome, salarioBase);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calcularSalario() {
	return salarioBase = salarioBase + 0.2;
		
	}
	
	
		

}
