package ba.senai.poo.gerenciamentoDeFuncionario;

import java.util.ArrayList;

public class Empresa {

	public static void main(String[] args) {
		
		ArrayList<Funcionario> funcionario = new ArrayList();

		Gerente gerente = new Gerente("Arthur",1500);
		Desenvolvedor desenvolvedor = new Desenvolvedor("Pedro",1200);
		
		funcionario.add(gerente);
		funcionario.add(desenvolvedor);
		 
		gerente.nome = "Arthur";
		desenvolvedor.nome = "Pedro";
		gerente.salarioBase = 1500;
		desenvolvedor.salarioBase = 1200;
		
		
		for (Funcionario funcionario2 : funcionario) {
			
			 System.out.println("Nome: " + funcionario2.nome);
	            System.out.println("Salário: " + funcionario2.salarioBase);
	            System.out.println("-------------------");
		}
	}

}
