package ba.senai.poo.tv;

public class Televisao {
	
	//atributos
	Integer volume = 0;
	Integer canal = 1;
	boolean ligado = false;
	
	
	
	public Integer getVolume() {
		return volume;
	}
	public void setVolume(Integer volume) {
		if(volume >= 0 && volume <= 100) {
		this.volume = volume;
		}
	}
	public Integer getCanal() {
		return canal;
	}
	public void setCanal(Integer canal) {
		if(canal <= 1 && canal >= 100) {
		this.canal = canal;
		}
	}
	public boolean isLigado() {
		return ligado;
	}
	public void setLigado(boolean ligado) {
		this.ligado = ligado;
	}
	
	
}
