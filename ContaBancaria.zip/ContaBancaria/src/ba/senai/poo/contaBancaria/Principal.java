package ba.senai.poo.contaBancaria;

public class Principal {

	public static void main(String[] args) {
		
		ContaBancaria conta = new ContaBancaria("Arthur Rocha",321.0,0.0);	
	
		
		conta.exibirDados();
		
		conta.setSaldo(-1.0);
		conta.exibirDados();
	}

}
