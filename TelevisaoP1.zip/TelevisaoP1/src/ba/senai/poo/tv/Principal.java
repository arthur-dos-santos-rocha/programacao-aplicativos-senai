package ba.senai.poo.tv;

public class Principal {

	public static void main(String[] args) {
		
		Televisao televisao = new Televisao();
		ControleRemoto controle = new ControleRemoto(televisao);
		
		controle.ligarTelevisao();
		controle.aumentarVolume();
		controle.aumentarVolume();
		controle.aumentarVolume();
		controle.trocarCanal(07);
		
		controle.consultar();
	}

}
