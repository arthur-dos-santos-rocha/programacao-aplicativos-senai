package ba.senai.poo.gerenciamentoDeFuncionario;

public abstract class Funcionario {

	String nome;
	double salarioBase;

	public Funcionario(String nome, double salarioBase) {
		super();
		this.nome = nome;
		this.salarioBase = salarioBase;
	}

	public abstract double calcularSalario();

	public static void exibirDados(String nome, double salarioBase) {
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}

}
