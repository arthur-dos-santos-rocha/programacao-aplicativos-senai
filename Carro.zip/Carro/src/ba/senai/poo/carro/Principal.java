package ba.senai.poo.carro;

public class Principal {

	public static void main(String[] args) {
		
		Carro carro = new Carro();
		
		carro.ligado = true;
		carro.cor = "Azul";
		carro.modelo = "Byd";
		carro.velocidadeAtual = 31;
		carro.velocidadeMaxima = 180;

		carro.consultar();
	}

}
