package ba.senai.poo.numerosInteiros;

import java.util.Scanner;

public class Inteiros {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		int[] numeros = new int[10];
		int soma =0;

		for (int i = 0; i < 10; i++) {
			System.out.println("Digite o " + (i+1) +" ° numero: ");
			
			numeros[i] = entrada.nextInt();
			soma += numeros[i];

		}
		System.out.println("Soma total é: " + soma);
		
		entrada.close();
	}
}
