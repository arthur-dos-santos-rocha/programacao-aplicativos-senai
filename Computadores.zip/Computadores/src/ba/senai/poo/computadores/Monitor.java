package ba.senai.poo.computadores;

public class Monitor {

	Integer tamanho;
	String tipoMonitor;
	double preco;
	
	
	public Monitor(Integer tamanho, String tipoMonitor, double preco) {
		super();
		this.tamanho = tamanho;
		this.tipoMonitor = tipoMonitor;
		this.preco = preco;
	}
	
	
}
