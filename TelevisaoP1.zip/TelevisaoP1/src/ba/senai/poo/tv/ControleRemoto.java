package ba.senai.poo.tv;

public class ControleRemoto {

	private Televisao tv;

	public ControleRemoto(Televisao tv) {
		this.tv = tv;
	}

	public void aumentarVolume() {
		if (tv.isLigado() && tv.getVolume() < 100) {
			tv.setVolume(tv.getVolume() + 1);
		}
	}

	public void diminuirVolume() {
		if (tv.isLigado() && tv.getVolume() > 0) {
			tv.setVolume(tv.getVolume() - 1);
		}
	}

	public void aumentarCanal() {
		if (tv.isLigado() && tv.getCanal() < 100) {
			this.tv.setCanal(tv.getCanal() + 1);
		}
	}

	public void diminuirCanal() {
		if (tv.isLigado() && tv.getCanal() > 1) {
			this.tv.setCanal(tv.getCanal() - 1);
		}
	}

	public void trocarCanal(Integer canal) {
		if (tv.isLigado() && canal >= 1 && canal <= 100) {
			tv.setCanal(canal);
		}
	}

	public void ligarTelevisao() {
		tv.setLigado(true);
	}

	public void desligarTelevisao() {
		tv.setLigado(false);
	}

	public void consultar() {

		System.out.println("Televisao = " + tv.isLigado());
		System.out.println("Volume = " + tv.getVolume());
		System.out.println("Canal = " + tv.getCanal());

		if (tv.getVolume() == 100) {
			System.out.println("O volume esta no Maximo");
		} else if (tv.getVolume() == 0) {
			System.out.println("O volume estar no MUDO");
		}

	}
}
